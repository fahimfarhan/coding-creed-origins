#include <iostream>

using namespace std;

class Node{
public: 
	int n; 
	Node *p;
	
	Node(){  n=0; p = this; }
	~Node(){}
};

class Edge{
public: 
	int u, v, w; /*here u= starting point, v= ending point, w = weight*/
	bool IsAdded;
	
	Edge(){  u=0; v=0; w=0; IsAdded = false;  }
	~Edge(){}
	//void AddEdge(int u, v, w){   this->u = u; this->v = v; this->w = w;  }
	void ShowEdge(){  cout<<"("<<u<<","<<v<<endl; }
	void AddToMST(){  IsAdded = true;  }
};

class A{
public: 
	Node *node; 
	int V; 
	
	A(int V){ this->V = V; node = new Node[V+1];for(int i=0; i<=V; i++) node[i].n = i;  }
	int FindSet(int u);
	void Union(int u, int v); 
	~A(){  delete []node; for(int i=0; i<=V; i++) node[i].p = NULL; }
};

int A::FindSet(int u){
	int x = node[u].p->n;
	if(x==u) return x; 
	else return FindSet(x); 
	
}

void A::Union(int u, int v){
	int x = FindSet(u);
	int y = FindSet(v); 
	node[x].p = &node[y];
}