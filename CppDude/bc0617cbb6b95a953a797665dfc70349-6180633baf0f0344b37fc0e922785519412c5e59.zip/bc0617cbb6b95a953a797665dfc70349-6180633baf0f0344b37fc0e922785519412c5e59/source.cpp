#include <iostream>
#include <algorithm>
#include <conio.h>
#include "kruskal.h"

using namespace std; 

bool SortByW(const Edge &e1, const Edge &e2 ){  return (e1.w<e2.w); }

int main()
{
	
	int V, E; 
	int u, v, w;
	
	cout<<"Enter V, E: \n"; 
	cin>>V>>E; 
	
	A k(V);
	Edge *e; 
	e = new Edge[E]; 
	
	/* Commencing Kruskal */
	// makeset done 
	
	cout<<"Now Enter the Edges: u, v, w : \n"; 
	for(int i=0; i<E; i++)
	{
		cin>>e[i].u>>e[i].v>>e[i].w; 	
	}
	// next sort the edges according to the weight
	sort(e, e+E, SortByW);
	
	for(int i=0; i<E; i++){
		u= e[i].u; 
		v= e[i].v; 
		if(k.FindSet(u)!=k.FindSet(v)){
			e[i].AddToMST();
			k.Union(u, v); 
		}
	}
	cout<<"Resulting MST: u  v\n";
	for(int i=0; i<E; i++){
		if(e[i].IsAdded)
		cout<<"("<<e[i].u<<","<<e[i].v<<")"<<endl; 
	}
	delete []e; 
	
	_getch();
	return 0;
}